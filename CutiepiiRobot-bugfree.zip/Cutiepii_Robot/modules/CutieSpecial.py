
__help__ = """
*QR code:*
 • `/getqr <reply to image>`*:* Read QR code
 • `/makeqr <reply to text>`*:* Make QR code
 
*Compress And Decompress:* 
 • `/zip`*:* reply to a telegram file to compress it in .zip format
 • `/unzip`*:* reply to a telegram file to decompress it from the .zip format
"""

__mod_name__ = "Tools"
