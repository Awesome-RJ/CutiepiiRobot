__mod_name__ = "upload"

__help__ = """
Here is the help for the Upload module:

*File To Link:*
 ⦁ `/transfersh`*:* reply to a telegram file to upload it on transfersh and get direct download link.
 ⦁ `/tmpninja`*:* reply to a telegram file to upload it on tmpninja and get direct download link.
 
*Link To File:*
 • `/up`*:* reply to a direct download link to upload it to telegram as files
 """
