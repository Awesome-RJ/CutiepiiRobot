from Cutiepii_Robot import DEV_USERS, DRAGONS, DEMONS, TIGERS, WOLVES, telethn

IMMUNE_USERS = DRAGONS + WOLVES + DEMONS + TIGERS + DEV_USERS

IMMUNE_USERS = (
    list(DRAGONS) + list(WOLVES) + list(DEMONS) + list(TIGERS) + list(DEV_USERS)
)
