chat_filters_group = 1
chatbot_group = 2
regex_group = 5
welcome_captcha_group = 6
antiflood_group = 7
karma_positive_group = 3
karma_negative_group = 4
