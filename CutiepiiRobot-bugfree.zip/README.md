![Cutiepii](https://telegra.ph/file/5058a17bd9447eb07a47f.png)
# 𝑪𝒖𝒕𝒊𝒆𝒑𝒊𝒊 𝑹𝒐𝒃𝒐𝒕
[![GPLv3 license](https://img.shields.io/badge/License-GPLv3-blue.svg)](http://perso.crans.org/besson/LICENSE.html) [![DeepSource](https://static.deepsource.io/deepsource-badge-light-mini.svg)](https://deepsource.io/gh/pokurt/LyndaRobot/?ref=repository-badge)
[![Codacy Badge](https://app.codacy.com/project/badge/Grade/41ee9ac813a34042925a6b6fa92cf84e)](https://www.codacy.com?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=AmaanAhmed/Lynda&amp;utm_campaign=Badge_Grade) [![Join Support!](https://img.shields.io/badge/Join%20Channel-!-red)](https://t.me/LyndaEagleSupport) [![Open Source Love](https://badges.frapsoft.com/os/v2/open-source.png?v=103)](https://github.com/ellerbrock/open-source-badges/) [![Maintenance](https://img.shields.io/badge/Maintained%3F-yes-green.svg)](https://GitHub.com/Naereen/StrapDown.js/graphs/commit-activity) [![GitHub contributors](https://img.shields.io/github/contributors/Naereen/StrapDown.js.svg)](https://GitHub.com/pokurt/LyndaRobot/graphs/contributors/)

A modular telegram Python bot running on python3 with an sqlalchemy, Redis, mongodb database.

Can be found on telegram as [Cutiepii](https://t.me/Cutiepii_Robot).

The Support group can be reached out to at [Black Knights Union](https://t.me/Black_Knights_Union), where you can ask for help setting up your bot, discover/request new features, report bugs, and stay in the loop whenever a new update is available. 

## Credits
The bot is based of on the original work done by [PaulSonOfLars](https://github.com/PaulSonOfLars)
This repo was just reamped to suit an Anime-centric community. All original credits go to Paul and his dedication, Without his efforts, this fork would not have been possible!

Thank you for contributing with me in this Project:
+ [Rajkumar](https://github.com/Awesome-RJ) : OWNER
+ [HuntingBots](https://github.com/HuntingBots) : ARQ MODULES
+ [TheRealPhoenix](https://github.com/rsktg) : BASE
+ [DragSama](https://github.com/DragSama) : ANIME
+ [TsunayoshiSawada](https://github.com/TsunayoshiSawada) : BASE
+ [Kittu](https://github.com/noob-kittu) : /START IMPROVE
+ [Pokurt](https://github.com/pokurt) : WHATANIME MODULE
+ [Pranav ⁪⁬⁮⁮⁮⁮Ajay](https://github.com/Red-Aura) : POKEDEX, CHATBOT API ETC
+ [Dank-del](https://github.com/Dank-del) : LEWD MODULE
+ [InukaAsith](https://github.com/InukaAsith) : MEMES, INLINE ETC MODULES 
+ [AyraHikari](https://github.com/AyraHikari): FED MODULE
+ [Peaktogoo](https://github.com/peaktogoo) : FED MODULE
+ [sasukeuchiha912](https://github.com/sasukeuchiha912) : PTB 13.6


Any other authorship/credits can be seen through the commits.

[![forthebadge made-with-python](http://ForTheBadge.com/images/badges/made-with-python.svg)](https://www.python.org/)

Should any be missing kindly let us know at [Yūki • Black Knights Union](https://t.me/Black_Knights_Union) or simply submit a pull request on the readme.
